# Docker 部署 Ollama + qwen3:0.6b 作业

## 文件说明

| 文件 | 作用 |
|------|------|
| `Dockerfile` | 基于 `ollama/ollama` 官方镜像，复制启动脚本 |
| `docker-compose.yml` | 定义服务：端口映射 11434、数据持久化卷 |
| `entrypoint.sh` | 容器启动脚本：启动 Ollama → 等就绪 → 拉取 qwen3:0.6b |
| `.dockerignore` | 排除不必要的文件 |

## 部署步骤

```bash
cd docker-ollama-qwen
docker compose up -d
```

首次启动会自动：
1. 构建镜像
2. 启动 Ollama 服务
3. 拉取 qwen3:0.6b 模型（约 500MB）

## Cherry Studio 调用

| 配置项 | 值 |
|--------|-----|
| API 地址 | `http://localhost:11434/v1` |
| 模型名 | `qwen3:0.6b` |
| API Key | `ollama` |

## 验证

```bash
curl http://localhost:11434/api/tags
curl -X POST http://localhost:11434/api/generate \
  -d '{"model":"qwen3:0.6b","prompt":"你好","stream":false}'
```
