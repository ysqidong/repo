#!/bin/sh
set -e

echo "[entrypoint] Starting Ollama server..."
ollama serve &
OLLAMA_PID=$!

echo "[entrypoint] Waiting for Ollama to be ready..."
# Retry up to 30 times (30 seconds), checking if the API responds
for i in $(seq 1 30); do
    if ollama list >/dev/null 2>&1; then
        echo "[entrypoint] Ollama is ready."
        break
    fi
    echo "[entrypoint] Waiting... ($i/30)"
    sleep 1
done

echo "[entrypoint] Pulling model qwen3:0.6b..."
ollama pull qwen3:0.6b

echo "[entrypoint] Model ready. Bringing Ollama serve to foreground."
wait $OLLAMA_PID
