"""命运石之门 — 游戏引擎"""
import db


def execute(player_id: int, cmd: str) -> str:
    """处理玩家指令"""
    cmd = cmd.strip().lower()
    state = db.get_game_state(player_id)
    if not state:
        return "未找到存档。请先注册/登录。"

    if cmd in ("help", "帮助", "h"):
        return HELP_TEXT

    if cmd in ("status", "状态", "s"):
        return _show_status(state, player_id)

    if cmd in ("look", "看", "l"):
        return _show_stage(state)

    if cmd in ("worldline", "世界线", "wl", "w"):
        return _show_worldline(state)

    if cmd in ("bag", "背包", "b", "i"):
        return _show_inventory(player_id)

    if cmd in ("restart", "重置", "重来"):
        db.reset_player(player_id)
        return "世界线已重置。El Psy Kongroo！\n\n" + _show_stage(db.get_game_state(player_id))

    if cmd in ("dmail", "dm", "发送"):
        return _show_dmail_tip(state)

    return f"未知指令: '{cmd}'。输入 'help' 查看可用指令。"


def process_choice(player_id: int, choice_id: int) -> str:
    """处理玩家选择，返回结果文本"""
    ok, result = db.apply_choice(player_id, choice_id)
    if not ok:
        return result.get("message", "错误")

    stage = result["stage"]
    worldline = result["worldline"]
    is_ending = result["is_ending"]

    lines = [
        f"▬" * 40,
        f"📡 世界线变动率: {worldline:.6f}",
        f"",
        f"📍 **{stage['title']}**",
        f"",
        stage["narrative"],
    ]

    if stage["char_speaker"] and stage["char_text"]:
        lines.append("")
        lines.append(f"「{stage['char_text']}」")
        lines.append(f"  —— {stage['char_speaker']}")

    lines.append(f"▬" * 40)

    if is_ending:
        lines.append("")
        lines.append("═" * 40)
        lines.append("🎬 结局达成！")
        lines.append("输入 '重置' 探索其他世界线，或输入 '状态' 查看成绩。")
        lines.append("═" * 40)

    return "\n".join(lines)


def _show_stage(state):
    stage = db.get_stage(state["stage_id"])
    if not stage:
        return "数据错误。"

    lines = [
        f"📍 **{stage['title']}**",
        f"",
        stage["narrative"],
    ]
    if stage["char_speaker"] and stage["char_text"]:
        lines.append("")
        lines.append(f"「{stage['char_text']}」")
        lines.append(f"  —— {stage['char_speaker']}")

    return "\n".join(lines)


def _show_worldline(state):
    wl = state["worldline"]
    if wl < 1.0:
        desc = "α世界线 —— 反乌托邦的未来"
    elif wl < 1.13:
        desc = "β世界线 —— 接近原本的世界线"
    elif wl < 1.14:
        desc = "γ世界线 —— 混沌的未知领域"
    else:
        desc = "Steins;Gate —— 命运的交叉点"

    return f"""📡 **世界线观测**
▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔
世界线变动率: {wl:.6f}
当前所在: {desc}
D-Mail发送次数: {state['dmail_count']}
▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔"""


def _show_status(state, player_id):
    inv = db.get_inventory(player_id)
    items = [i["item_name"] for i in inv]
    return f"""📊 **当前状态** — El Psy Kongroo
▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔
📡 世界线: {state['worldline']:.6f}
❤️ 红莉栖好感: {'█' * min(state['friendship_kurisu'], 10)}{'░' * max(0, 10 - state['friendship_kurisu'])} ({state['friendship_kurisu']})
🕊️ 真由理好感: {'█' * min(state['friendship_mayuri'], 10)}{'░' * max(0, 10 - state['friendship_mayuri'])} ({state['friendship_mayuri']})
📧 D-Mail: {state['dmail_count']}次
🎒 关键物品: {', '.join(items) if items else '无'}
▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔"""


def _show_inventory(player_id):
    items = db.get_inventory(player_id)
    if not items:
        return "🎒 背包空空如也。去发现D-Mail的真相吧！"
    lines = ["🎒 **关键物品**", ""]
    for item in items:
        lines.append(f"  📦 {item['item_name']}")
    return "\n".join(lines)


def _show_dmail_tip(state):
    return """📧 **D-Mail系统**
▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔
D-Mail（DeLorean Mail）可以将短信发送到过去，
从而改变世界线。

⚠️ 每次发送D-Mail都会改变世界线变动率，
引发不可预测的蝴蝶效应。
▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔
请通过游戏中的选项来发送D-Mail。"""


HELP_TEXT = """📜 **指令列表**
▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔
👁️  look / 看     — 查看当前剧情
📡 worldline / 世界线 — 查看世界线数值
📊 status / 状态  — 查看角色好感度和物品
🎒 bag / 背包     — 查看关键物品
📧 dmail          — 了解D-Mail系统
🔄 restart / 重置 — 重置世界线
▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔
El Psy Kongroo！"""
