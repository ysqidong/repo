# Steins;Gate — 世界线漂流

> **El Psy Kongroo！**

基于《命运石之门》世界观开发的交互式视觉小说游戏。通过选择改变世界线，走向不同的结局。

---

## 🚀 快速开始

### 方式一：Docker（推荐，零配置）

```bash
docker-compose up -d
```

浏览器打开 `http://localhost:9090`

### 方式二：本地 Python 运行

```bash
pip install -r requirements.txt
python web_server.py
```

浏览器打开 `http://localhost:9090`

---

## 🎮 游戏机制

| 系统 | 说明 |
|------|------|
| 📡 **世界线变动率** | 初始 1.048596，每次选择改变数值 |
| ❤️ **好感度** | 牧濑红莉栖 / 椎名真由理，影响结局 |
| 📧 **D-Mail** | 发送短信到过去，改变命运 |
| 🎒 **关键物品** | IBM5100 等，解锁隐藏分支 |
| 🎬 **4 结局** | 真结局 / 牺牲守护 / 无限循环 / 欺骗世界 |

### 世界线区域

- `< 1.0` — α世界线（反乌托邦未来）
- `1.0 ~ 1.13` — β世界线（接近原本）
- `1.13 ~ 1.14` — γ世界线（混沌未知）
- `> 1.14` — **Steins;Gate**（命运交叉点）

### 内置指令

在游戏终端输入：

| 指令 | 功能 |
|------|------|
| `look` / `看` | 查看当前剧情 |
| `worldline` / `世界线` | 查看世界线数值 |
| `status` / `状态` | 查看好感度和物品 |
| `bag` / `背包` | 查看关键物品 |
| `dmail` | 了解D-Mail系统 |
| `restart` / `重置` | 重置世界线重新开始 |

---

## 🤖 MCP Server

项目包含 MCP（Model Context Protocol）服务器，可通过 AI Agent 交互游玩。

```bash
python mcp_server.py
```

**可用工具**：`sg_register` `sg_login` `sg_status` `sg_stage` `sg_choose` `sg_worldline` `sg_reset`

---

## 📁 项目结构

```
detective-novel/
├── db.py              # SQLite 数据库（自动初始化）
├── game_engine.py     # 游戏引擎（世界线/好感度/D-Mail）
├── web_server.py      # FastAPI Web 服务器
├── mcp_server.py      # MCP Server（stdio协议）
├── static/
│   └── index.html     # 前端UI（命运石之门暗黑主题）
├── Dockerfile         # Docker 镜像
├── docker-compose.yml # Docker Compose 编排
├── requirements.txt   # Python 依赖
└── data/              # SQLite 数据持久化（自动创建）
```

---

## 🔌 API 接口

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/api/register` | 注册 `{username, password}` |
| POST | `/api/login` | 登录 `{username, password}` |
| POST | `/api/choose` | 选择分支 `{player_id, choice_id}` |
| POST | `/api/command` | 执行指令 `{player_id, command}` |
| GET | `/api/state/{player_id}` | 查询状态 |

---

## 🎬 结局达成条件

| 结局 | 条件 |
|------|------|
| 🏆 **Steins;Gate 真结局** | 红莉栖好感 ≥ 6 |
| 💔 **牺牲守护** | 选择牺牲红莉栖 |
| ♾️ **无限循环** | 接受真由理死亡的命运 |
| 📜 **欺骗世界** | 获得 IBM5100 → 欺骗过去的自己 |
