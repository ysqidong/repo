"""命运石之门 — FastAPI Web 服务器"""
from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
import db
import game_engine

app = FastAPI(title="Steins;Gate - Worldline Adventure", version="1.0")
db.init_db()


# ─── 请求模型 ───
class RegisterReq(BaseModel):
    username: str
    password: str


class LoginReq(BaseModel):
    username: str
    password: str


class ChoiceReq(BaseModel):
    player_id: int
    choice_id: int


class CommandReq(BaseModel):
    player_id: int
    command: str


# ─── API ───

@app.post("/api/register")
def api_register(req: RegisterReq):
    ok, pid, msg = db.register_player(req.username, req.password)
    if not ok:
        raise HTTPException(400, msg)
    return {"player_id": pid, "message": msg}


@app.post("/api/login")
def api_login(req: LoginReq):
    pid, msg = db.login_player(req.username, req.password)
    if pid is None:
        raise HTTPException(401, msg)
    state = db.get_game_state(pid)
    stage = db.get_stage(state["stage_id"])
    choices = db.get_choices(state["stage_id"], pid)
    return {
        "player_id": pid, "message": msg,
        "stage": stage,
        "choices": [{
            "id": c["id"], "text": c["choice_text"],
            "worldline_delta": c["worldline_delta"],
        } for c in choices],
        "worldline": state["worldline"],
        "friendship_kurisu": state["friendship_kurisu"],
        "friendship_mayuri": state["friendship_mayuri"],
        "dmail_count": state["dmail_count"],
    }


@app.post("/api/choose")
def api_choose(req: ChoiceReq):
    ok, result = db.apply_choice(req.player_id, req.choice_id)
    if not ok:
        raise HTTPException(400, result.get("message", "无效选择"))
    # 转换字段名: choice_text → text，前端才认
    result["choices"] = [{"id": c["id"], "text": c["choice_text"],
                          "worldline_delta": c["worldline_delta"]} for c in result["choices"]]
    return result


@app.post("/api/command")
def api_command(req: CommandReq):
    state = db.get_game_state(req.player_id)
    if not state:
        raise HTTPException(404, "玩家不存在，请重新登录。")
    result = game_engine.execute(req.player_id, req.command)
    state = db.get_game_state(req.player_id)
    choices = db.get_choices(state["stage_id"], req.player_id)
    return {
        "result": result,
        "stage_id": state["stage_id"],
        "choices": [{"id": c["id"], "text": c["choice_text"],
                      "worldline_delta": c["worldline_delta"]} for c in choices],
        "worldline": state["worldline"],
        "friendship_kurisu": state["friendship_kurisu"],
        "friendship_mayuri": state["friendship_mayuri"],
        "dmail_count": state["dmail_count"],
    }


@app.get("/api/state/{player_id}")
def api_state(player_id: int):
    state = db.get_game_state(player_id)
    if not state:
        raise HTTPException(404, "玩家不存在")
    choices = db.get_choices(state["stage_id"], player_id)
    inv = db.get_inventory(player_id)
    return {
        "state": state,
        "choices": [{"id": c["id"], "text": c["choice_text"]} for c in choices],
        "inventory": [i["item_name"] for i in inv],
    }


# 静态文件
app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/")
def root():
    return FileResponse("static/index.html")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=9090)
