"""命运石之门 — 数据库模块"""
import sqlite3
import hashlib
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "data", "steins_gate.db")


def get_conn():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db():
    conn = get_conn()
    cur = conn.cursor()
    cur.executescript("""
    CREATE TABLE IF NOT EXISTS players (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS game_state (
        player_id INTEGER PRIMARY KEY,
        worldline REAL DEFAULT 1.048596,
        stage_id TEXT DEFAULT 'prologue',
        friendship_kurisu INTEGER DEFAULT 0,
        friendship_mayuri INTEGER DEFAULT 0,
        dmail_count INTEGER DEFAULT 0,
        has_ibm5100 INTEGER DEFAULT 0,
        has_phone_mw INTEGER DEFAULT 1,
        ending_flag TEXT DEFAULT '',
        FOREIGN KEY (player_id) REFERENCES players(id)
    );

    CREATE TABLE IF NOT EXISTS inventory (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        player_id INTEGER NOT NULL,
        item_name TEXT NOT NULL,
        FOREIGN KEY (player_id) REFERENCES players(id)
    );

    CREATE TABLE IF NOT EXISTS stages (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        narrative TEXT NOT NULL,
        char_speaker TEXT DEFAULT '',
        char_text TEXT DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS choices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        stage_id TEXT NOT NULL,
        choice_text TEXT NOT NULL,
        next_stage_id TEXT NOT NULL,
        worldline_delta REAL DEFAULT 0,
        friendship_kurisu_delta INTEGER DEFAULT 0,
        friendship_mayuri_delta INTEGER DEFAULT 0,
        item_reward TEXT DEFAULT '',
        condition_item TEXT DEFAULT '',
        condition_friendship TEXT DEFAULT ''
    );
    """)

    cur.execute("SELECT COUNT(*) FROM stages")
    if cur.fetchone()[0] == 0:
        _init_story(cur)

    conn.commit()
    conn.close()


def _init_story(cur):
    """命运石之门风格分支故事"""
    stages = [
        # ═══ 序章 ═══
        ("prologue", "序章：秋叶原的疯狂科学家",
         "2010年7月28日，秋叶原。\n\n"
         "在大楼楼顶，你——凤凰院凶真（本名：冈部伦太郎）——\n"
         "正在和桥田至（桶子）测试「电话微波炉（暂定）」的奇怪现象。\n\n"
         "当你把手机对准微波炉里的香蕉时，香蕉消失了……\n"
         "取而代之的是一团绿色凝胶状物质。\n\n"
         "『这就是……时间机器？！』\n\n"
         "就在这时，传来敲门声。",
         "凤凰院凶真", "『机关』终于找上门了吗？！"),
        # ═══ 第一章：相遇 ═══
        ("ch1_meeting", "第一章：天才少女",
         "门外站着一位红发的少女。\n\n"
         "她是牧濑红莉栖，年仅18岁的天才脑科学家，\n"
         "刚从美国留学归来，在秋叶原的大学做研究。\n\n"
         "『你是……下午在广播会馆看到的那个人？』她惊讶地看着你。\n\n"
         "但你觉得她似乎在隐瞒什么。她为什么会在这里？\n"
         "她与电话微波炉有什么联系？",
         "牧濑红莉栖", "『你……你还活着？！』"),
        ("ch1_sern", "第一章：SERN的阴影",
         "在调查电话微波炉的过程中，你发现了一个惊人的事实：\n\n"
         "欧洲核子研究组织——SERN——一直在秘密进行时间机器研究。\n"
         "他们利用大型强子对撞机（LHC）制造微型黑洞，\n"
         "从而扭曲时空。\n\n"
         "更可怕的是，SERN已经成功地……\n"
         "将人类送回了过去。但所有实验体都变成了胶状。\n\n"
         "而你的电话微波炉做到了同样的事情。",
         "桥田至", "『凶真，我们好像发现了不得了的秘密……』"),
        # ═══ D-Mail 发现 ═══
        ("ch2_dmail", "第二章：D-Mail",
         "实验有了突破性进展。\n\n"
         "你将手机连接到电话微波炉后，尝试发送了一条短信到过去。\n"
         "内容只有一句话：『助手在吗？』\n\n"
         "——世界，改变了。\n\n"
         "你的「Reading Steiner」能力发动了。\n"
         "你的意识保留了变动前的记忆，但周围的一切都不同了。\n"
         "你成功地向过去发送了第一封D-Mail。",
         "凤凰院凶真", "『这就是——命运石之门的选择！』"),
        # ═══ 关键选择1 ═══
        ("choice1_mayuri", "选择：真由理的命运",
         "椎名真由理——你从小一起长大的青梅竹马。\n"
         "她总是用「嘟嘟噜」的问候语，傻傻地笑着。\n\n"
         "但世界线计算显示，在当前的轨迹上，\n"
         "真由理将于8月13日——死亡。\n\n"
         "你可以发送D-Mail，改变她的命运。\n"
         "但每一次改变世界线，都会引发不可预测的蝴蝶效应……\n\n"
         "要发送D-Mail吗？",
         "椎名真由理", "『嘟嘟噜～冈伦，你看起来好严肃哦！』"),
        ("dmail_sent_mayuri", "D-Mail 发送",
         "你颤抖着手指按下了发送键。\n\n"
         "『真由理，不要出门！』\n\n"
         "世界在你眼前扭曲、重组。\n"
         "Reading Steiner发动，你的意识穿越了世界线。\n\n"
         "世界线变动率：1.130205 → 1.130426\n"
         "真由理活下来了——但代价是什么？",
         "凤凰院凶真", "『我绝不会让你死！』"),
        ("dmail_not_sent", "无法接受的现实",
         "你没有发送D-Mail。\n\n"
         "不是不想，而是害怕。\n"
         "害怕改变世界线带来的连锁反应。\n"
         "害怕失去更多。\n\n"
         "但你每天看着真由理的笑容，\n"
         "内心在一点点崩溃……\n\n"
         "你还有机会。时间还在流动。",
         "凤凰院凶真", "『我不能冒险……但我真的对吗？』"),
        # ═══ 关键选择2：红莉栖 ═══
        ("choice2_kurisu", "选择：红莉栖的真相",
         "在研究D-Mail的过程中，你发现了一个恐怖的事实：\n\n"
         "牧濑红莉栖——在原本的世界线上，已经死了。\n"
         "是第一封D-Mail意外地救了她。\n\n"
         "但如果要回到原本的世界线，回到真由理不会死的世界，\n"
         "你必须撤销最初的D-Mail……\n"
         "这意味着——红莉栖会死。\n\n"
         "『这是命运石之门的选择吗……』",
         "牧濑红莉栖", "『没关系的，冈部。去做你认为正确的事。』"),
        ("i_am_mad_scientist", "狂气的疯狂科学家",
         "你是凤凰院凶真！不会被命运束缚的疯狂科学家！\n\n"
         "你拒绝接受「必须牺牲一个」的命运。\n"
         "你开始疯狂地计算世界线，寻找第三条道路——\n"
         "一条既不牺牲真由理、也不牺牲红莉栖的道路。\n\n"
         "那就是……命运石之门（Steins;Gate）。\n"
         "世界线变动率：1.048596。\n"
         "这是通往未知领域的世界线。",
         "凤凰院凶真", "『欺骗世界吧！欺骗最初的你！欺骗你自己！』"),
        # ═══ 结局 ═══
        ("ending_true", "🌟 真结局：命运石之门",
         "你成功了。\n\n"
         "通过欺骗过去的自己，你保留了D-Mail的关键信息，\n"
         "同时避免了SERN的注意。\n\n"
         "在命运石之门世界线上：\n"
         "真由理活着，红莉栖也活着。\n"
         "世界线变动率：1.048596。\n\n"
         "红莉栖在秋天的阳光中微笑。\n"
         "『这一次……你可以永远陪在我身边吗？』\n\n"
         "『El Psy Kongroo。』",
         "牧濑红莉栖", "『El Psy Kongroo……我也开始懂了。』"),
        ("ending_kurisu", "💔 结局：牺牲的守护",
         "你选择了撤销最初的D-Mail。\n\n"
         "世界线回到了最初的状态。\n"
         "真由理活着。但红莉栖……\n\n"
         "你站在广播会馆的楼顶，亲眼看着她倒下。\n"
         "这一次，你没有发D-Mail。\n\n"
         "『谢谢你，冈部。你拯救了世界……』\n"
         "她的声音永远刻在了你的Reading Steiner里。\n\n"
         "世界线变动率：1.130238。\n"
         "这是真由理活着的世界——也是你永远失去她的世界。",
         "凤凰院凶真", "『助手……我……』"),
        ("ending_mayuri", "🕊️ 结局：无限的循环",
         "你一次又一次发送D-Mail拯救真由理。\n"
         "但每一次，她都会以不同的方式死去。\n"
         "你陷入了无限循环。\n\n"
         "世界线变动率一直在变，但终点始终是悲剧。\n"
         "你的精神快要崩溃了。\n\n"
         "直到有一天，真由理发现了真相。\n"
         "『冈伦……不要再为我受苦了。』\n"
         "她温柔地笑着，握住了你的手。\n\n"
         "也许，最好的爱，是学会放手。",
         "椎名真由理", "『嘟嘟噜……再见了，我最喜欢的冈伦。』"),
        ("ending_deceive", "🎭 结局：欺骗世界",
         "你制定了一个巧妙的计划——\n"
         "欺骗过去的自己，欺骗整个世界！\n\n"
         "你让过去的自己看到红莉栖倒下，\n"
         "但实际她并没有死——只是昏迷。\n"
         "过去的你发D-Mail救了她的「命」……\n"
         "而实际她从未真正死去。\n\n"
         "你欺骗了世界线本身。\n"
         "但红莉栖看着你，眼神复杂。\n"
         "『你……到底是谁？』\n"
         "她不再记得你。你在她的世界里从来不存在。\n\n"
         "她活着——但你是陌生人。",
         "凤凰院凶真", "『这是……命运石之门的选择吗？不，这是我的选择。』"),
    ]
    cur.executemany(
        "INSERT INTO stages(id, title, narrative, char_speaker, char_text) VALUES(?,?,?,?,?)",
        stages,
    )

    # ─── 选择分支 ───
    choices = [
        # 序章 → 第一章
        ("prologue", "🚪 打开门", "ch1_meeting", 0.001, 1, 0, "", "", ""),
        ("prologue", "🔒 装作不在", "ch1_sern", -0.001, -1, 0, "", "", ""),
        # 第一章 → 第二章（两种汇合）
        ("ch1_meeting", "🧪 展示电话微波炉", "ch2_dmail", 0.003, 2, 0, "", "", ""),
        ("ch1_meeting", "🤐 保守秘密", "ch1_sern", -0.002, -1, 0, "", "", ""),
        ("ch1_sern", "🔍 继续调查SERN", "ch2_dmail", 0.005, 0, 1, "IBM5100", "", ""),
        ("ch1_sern", "🧪 回去研究微波炉", "ch2_dmail", 0.001, 1, 0, "", "", ""),
        # 第二章 D-Mail → 关键选择1
        ("ch2_dmail", "💌 发送D-Mail救真由理", "dmail_sent_mayuri", 0.010, 0, 3, "", "", ""),
        ("ch2_dmail", "😰 不敢发送D-Mail", "dmail_not_sent", -0.005, -1, -2, "", "", ""),
        # 发送后 → 选择2
        ("dmail_sent_mayuri", "❤️ 不能牺牲红莉栖", "i_am_mad_scientist", 0.020, 3, 0, "", "", "kurisu>=3"),
        ("dmail_sent_mayuri", "💔 撤销D-Mail救真由理", "ending_kurisu", -0.030, -2, 2, "", "", ""),
        ("dmail_not_sent", "🔄 回头发送D-Mail", "dmail_sent_mayuri", 0.015, 0, 2, "", "", ""),
        ("dmail_not_sent", "🚶 接受命运", "ending_mayuri", -0.010, 0, 3, "", "", ""),
        # 狂气的科学家 → 最终结局
        ("i_am_mad_scientist", "🔮 欺骗世界", "ending_deceive", 0.000, 1, 1, "", "IBM5100", ""),
        ("i_am_mad_scientist", "🌟 寻找命运石之门", "ending_true", -0.002, 2, 1, "", "", "kurisu>=6"),
        ("i_am_mad_scientist", "💔 放弃……", "ending_kurisu", -0.010, -3, 0, "", "", ""),
    ]
    cur.executemany(
        "INSERT INTO choices(stage_id, choice_text, next_stage_id, worldline_delta, "
        "friendship_kurisu_delta, friendship_mayuri_delta, item_reward, "
        "condition_item, condition_friendship) VALUES(?,?,?,?,?,?,?,?,?)",
        choices,
    )


# ─── 玩家操作 ───

def register_player(username: str, password: str):
    conn = get_conn()
    try:
        h = hashlib.sha256(password.encode()).hexdigest()
        cur = conn.cursor()
        cur.execute("INSERT INTO players(username, password_hash) VALUES(?,?)", (username, h))
        pid = cur.lastrowid
        cur.execute("INSERT INTO game_state(player_id) VALUES(?)", (pid,))
        conn.commit()
        return True, pid, f"欢迎，{username}！El Psy Kongroo！"
    except sqlite3.IntegrityError:
        conn.close()
        return False, None, "用户名已存在"
    finally:
        if conn:
            conn.close()


def login_player(username: str, password: str):
    conn = get_conn()
    cur = conn.cursor()
    h = hashlib.sha256(password.encode()).hexdigest()
    cur.execute("SELECT id FROM players WHERE username=? AND password_hash=?", (username, h))
    row = cur.fetchone()
    conn.close()
    if row:
        return row["id"], f"欢迎回来，{username}！世界线在等待着你。"
    return None, "用户名或密码错误"


def get_game_state(player_id: int):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM game_state WHERE player_id=?", (player_id,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def get_stage(stage_id: str):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM stages WHERE id=?", (stage_id,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def get_choices(stage_id: str, player_id: int):
    """获取可选分支，根据玩家状态过滤条件"""
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM choices WHERE stage_id=?", (stage_id,))
    rows = cur.fetchall()

    # 获取玩家状态用于条件检查
    state = dict(cur.execute("SELECT * FROM game_state WHERE player_id=?", (player_id,)).fetchone())
    inv = [dict(r) for r in cur.execute("SELECT item_name FROM inventory WHERE player_id=?", (player_id,)).fetchall()]
    item_names = [i["item_name"] for i in inv]
    conn.close()

    result = []
    for r in rows:
        choice = dict(r)
        # 检查物品条件
        if choice["condition_item"] and choice["condition_item"] not in item_names:
            continue
        # 检查好感度条件: 格式 "kurisu>=6" 或 "mayuri>=3"
        cf = choice["condition_friendship"]
        if cf:
            if "kurisu" in cf:
                val = int(cf.split(">=")[-1])
                if state["friendship_kurisu"] < val:
                    continue
            if "mayuri" in cf:
                val = int(cf.split(">=")[-1])
                if state["friendship_mayuri"] < val:
                    continue
        result.append(choice)

    return result


def get_inventory(player_id: int):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM inventory WHERE player_id=?", (player_id,))
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def apply_choice(player_id: int, choice_id: int):
    conn = get_conn()
    cur = conn.cursor()

    cur.execute("SELECT * FROM choices WHERE id=?", (choice_id,))
    choice = cur.fetchone()
    if not choice:
        conn.close()
        return False, {"message": "无效的选择"}

    state = dict(cur.execute("SELECT * FROM game_state WHERE player_id=?", (player_id,)).fetchone())

    # 验证选项属于当前阶段
    if choice["stage_id"] != state["stage_id"]:
        conn.close()
        return False, {"message": "此选项不属于当前阶段"}

    # 计算新世界线
    new_wl = round(state["worldline"] + choice["worldline_delta"], 6)
    new_kurisu = state["friendship_kurisu"] + choice["friendship_kurisu_delta"]
    new_mayuri = state["friendship_mayuri"] + choice["friendship_mayuri_delta"]

    # D-Mail发送检测：选择文字中含"D-Mail"且不是"不敢发送"则计为一次
    choice_text = choice["choice_text"]
    new_dmail = state["dmail_count"]
    if "D-Mail" in choice_text and "不敢" not in choice_text:
        new_dmail += 1

    cur.execute(
        "UPDATE game_state SET worldline=?, stage_id=?, friendship_kurisu=?, friendship_mayuri=?, dmail_count=? WHERE player_id=?",
        (new_wl, choice["next_stage_id"], new_kurisu, new_mayuri, new_dmail, player_id),
    )

    if choice["item_reward"]:
        cur.execute("INSERT INTO inventory(player_id, item_name) VALUES(?,?)",
                    (player_id, choice["item_reward"]))

    conn.commit()

    stage = get_stage(choice["next_stage_id"])
    remaining_choices = get_choices(choice["next_stage_id"], player_id)
    is_ending = len(remaining_choices) == 0

    conn.close()
    return True, {
        "stage": stage,
        "choices": remaining_choices,
        "is_ending": is_ending,
        "worldline": new_wl,
        "friendship_kurisu": new_kurisu,
        "friendship_mayuri": new_mayuri,
        "dmail_count": new_dmail,
    }


def reset_player(player_id: int):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("DELETE FROM game_state WHERE player_id=?", (player_id,))
    cur.execute("DELETE FROM inventory WHERE player_id=?", (player_id,))
    cur.execute("INSERT INTO game_state(player_id) VALUES(?)", (player_id,))
    conn.commit()
    conn.close()
