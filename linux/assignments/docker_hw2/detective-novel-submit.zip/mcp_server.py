"""命运石之门 — MCP Server (stdio)"""
import json
import sys
import db
import game_engine

db.init_db()
current_player = None


def send(req_id, result):
    sys.stdout.write(json.dumps({"jsonrpc": "2.0", "id": req_id, "result": result}, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def err(req_id, code, msg):
    sys.stdout.write(json.dumps({"jsonrpc": "2.0", "id": req_id, "error": {"code": code, "message": msg}}, ensure_ascii=False) + "\n")
    sys.stdout.flush()


TOOLS = [
    {
        "name": "sg_register",
        "description": "注册新玩家。",
        "inputSchema": {
            "type": "object",
            "properties": {
                "username": {"type": "string", "description": "用户名"},
                "password": {"type": "string", "description": "密码"},
            },
            "required": ["username", "password"],
        },
    },
    {
        "name": "sg_login",
        "description": "登录账号。",
        "inputSchema": {
            "type": "object",
            "properties": {
                "username": {"type": "string", "description": "用户名"},
                "password": {"type": "string", "description": "密码"},
            },
            "required": ["username", "password"],
        },
    },
    {
        "name": "sg_status",
        "description": "查看当前状态：世界线、好感度、物品。",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "sg_stage",
        "description": "查看当前剧情场景。",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "sg_choose",
        "description": "选择剧情分支。",
        "inputSchema": {
            "type": "object",
            "properties": {
                "choice_id": {"type": "integer", "description": "选择ID"},
            },
            "required": ["choice_id"],
        },
    },
    {
        "name": "sg_worldline",
        "description": "查看世界线变动率。",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "sg_reset",
        "description": "重置世界线，重新开始。",
        "inputSchema": {"type": "object", "properties": {}},
    },
]


def handle(req):
    global current_player
    rid = req.get("id")
    method = req.get("method")
    params = req.get("params", {})

    if method == "initialize":
        send(rid, {
            "protocolVersion": "2024-11-05",
            "capabilities": {"tools": {}},
            "serverInfo": {"name": "steins-gate-mcp", "version": "1.0"},
        })
    elif method == "tools/list":
        send(rid, {"tools": TOOLS})
    elif method == "tools/call":
        name = params.get("name")
        args = params.get("arguments", {})
        try:
            if name == "sg_register":
                ok, pid, msg = db.register_player(args["username"], args["password"])
                if ok:
                    current_player = pid
                send(rid, {"content": [{"type": "text", "text": msg}]})
            elif name == "sg_login":
                pid, msg = db.login_player(args["username"], args["password"])
                if pid:
                    current_player = pid
                    stage = db.get_stage(db.get_game_state(pid)["stage_id"])
                    send(rid, {"content": [{"type": "text", "text": msg + "\n\n" + game_engine._show_stage(db.get_game_state(pid))}]})
                else:
                    send(rid, {"content": [{"type": "text", "text": msg}]})
            elif name == "sg_status":
                if not current_player:
                    send(rid, {"content": [{"type": "text", "text": "请先登录。"}]}); return
                send(rid, {"content": [{"type": "text", "text": game_engine._show_status(db.get_game_state(current_player), current_player)}]})
            elif name == "sg_stage":
                if not current_player:
                    send(rid, {"content": [{"type": "text", "text": "请先登录。"}]}); return
                send(rid, {"content": [{"type": "text", "text": game_engine._show_stage(db.get_game_state(current_player))}]})
            elif name == "sg_choose":
                if not current_player:
                    send(rid, {"content": [{"type": "text", "text": "请先登录。"}]}); return
                txt = game_engine.process_choice(current_player, args["choice_id"])
                send(rid, {"content": [{"type": "text", "text": txt}]})
            elif name == "sg_worldline":
                if not current_player:
                    send(rid, {"content": [{"type": "text", "text": "请先登录。"}]}); return
                send(rid, {"content": [{"type": "text", "text": game_engine._show_worldline(db.get_game_state(current_player))}]})
            elif name == "sg_reset":
                if not current_player:
                    send(rid, {"content": [{"type": "text", "text": "请先登录。"}]}); return
                db.reset_player(current_player)
                send(rid, {"content": [{"type": "text", "text": "世界线已重置。\n\n" + game_engine._show_stage(db.get_game_state(current_player))}]})
            else:
                err(rid, -32601, f"Unknown tool: {name}")
        except Exception as e:
            err(rid, -32000, str(e))
    elif method == "notifications/initialized":
        pass
    else:
        err(rid, -32601, f"Unknown: {method}")


if __name__ == "__main__":
    for line in sys.stdin:
        try:
            handle(json.loads(line.strip()))
        except:
            pass
